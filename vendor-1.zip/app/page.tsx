import { ProfessionalLandingPage } from "@/components/ProfessionalLandingPage"

export default function Home() {
  return <ProfessionalLandingPage />
}
